print('Hello Python')
a = int(input('Enter a: '))
print(a)